function Wave(_freq, _amp, _plane, _colour, _stroke)
{
	//Wave attributes
	this.freq = _freq;
	this.amp = _amp;

	//Draw attributes
	this.colour = _colour;
	this.stroke = _stroke;

	//Plane attributes
	this.plane = _plane;
	this.startX = plane.x_axis_min+plane.x_line_buffer;
	this.startY = plane.center_height;

	this.draw = function()
	{
		strokeWeight(this.stroke);
    	stroke(this.colour,180);
    	
		beginShape();
    
	    vertex(this.startX, this.startY);
	    
	    for (var c=1; c < amount; c++) 
	    {
	    	var sinoffset = sin(thisfreq*-c);
	    	var sinX = c*(plane.x_axis_max/amount);
	    	var sinY = this.startY + (sinoffset*this.amp);
	    	bezierVertex(sinX,sinY,sinX,sinY,sinX,sinY);
	    }

	    endShape();
	}
}